from django.core.checks import messages
import requests
import json

from api.views import Sms
from django.shortcuts import render
from django.urls import reverse

# Create your views here.
from api.models import Sms
from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
from api.models import *
from .filter import *
#from .form import *


def home(request):
    #forms = homeform
    
   # if forms.is_valid ():
    #    text =forms.cleaned_data['post']
    context= {
            #"form": form,
            #"text": text,
        #'myFilter':myFilter,
        "welcome": "welcome to penzi sms penzi to 5001 to get started ",
    }

    ins = Sms(messages=messages) 
    ins.save

    return render(request, 'penzi/home.html',context)

def dating(request):

    return render(request, 'penzi/dating.html',{'dating':dating})

def myself(request):
    data = request.POST.get('name')
    print(data)
 
    return render(request, 'penzi/myself.html',{'data':data})

def register(request):
    register = requests.post(request.build_absolute_uri(reverse("dates")))
    #data = json.loads(data.text)
    # for mtched in data:
    #     print(data)
    #     print(data)
    # myFilter = UserFilter(request.GET, queryset= id)
    #  = myFilter.qs

    context= {

        "form" : register,
        #'myFilter':myFilter,
        "message": "stephen texting",
         "name": ['name']
     }
    
    return render(request, 'penzi/register.html',context)
def details(request):
    # data = request.POST.get('name')
    data = requests.get(request.build_absolute_uri(reverse("dates")))
    data = json.loads(data.text)
    print(data)

    context = {
        "data" : data,
        "name": "steven",
        
    }
 
    return render(request, 'penzi/details.html',context)
def describe(request):
    data = request.POST.get('name')
    print(data)
 
    return render(request, 'penzi/describe.html',{'data':data})