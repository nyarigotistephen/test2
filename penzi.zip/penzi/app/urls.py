from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from . import views

urlpatterns = [
   
    path('',views.home),
    path('register/',views.register),
    path('register/details/',views.details),
    path('register/details/describe/',views.describe),
    path('register/details/describe/myself/',views.myself),
    path('register/details/describe/myself/dating/',views.dating),
   
]


