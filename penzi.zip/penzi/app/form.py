# from django import forms


# class homeform(forms.Form):
#     post = forms.CharField()