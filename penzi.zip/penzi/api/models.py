from django.db import models

# Create your models here.
class Dates(models.Model):
    matched = models.CharField(max_length=10)
    open = models.FloatField()
    close = models.FloatField()
    volume = models.CharField(max_length=12)

    def __str__(self):
        return self.matched


class User(models.Model):
    name = models.CharField(max_length=200, null=True)
    phonenumber = models.CharField(max_length=200, null=True)
    age = models.CharField(max_length=200, null=True)
    gender = models.CharField(max_length=200, null=True)
    tribe = models.CharField(max_length=200, null=True)
    religion = models.CharField(max_length=200, null=True)
    town = models.CharField(max_length=200, null=True)
    province = models.CharField(max_length=200, null=True)
    education = models.CharField(max_length=200, null=True)
    joining_date = models.DateTimeField(auto_now_add=True, null=True)


    def __str__(self):
        return self.name

class Match(models.Model):
    name = models.CharField(max_length=200, null=True)
    phonenumber = models.CharField(max_length=200, null=True)
    age = models.CharField(max_length=200, null=True)
    gender = models.CharField(max_length=200, null=True)
    tribe = models.CharField(max_length=200, null=True)
    religion = models.CharField(max_length=200, null=True)
    town = models.CharField(max_length=200, null=True)
    province = models.CharField(max_length=200, null=True)
    education = models.CharField(max_length=200, null=True)
    joining_date = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return self.name
        

class Sms(models.Model):
    messagesid = models.CharField(max_length=200, null=True)
    messages = models.CharField(max_length=200, null=True)

    def __str__(self):
        return self.messages


class Location(models.Model):
    province = models.CharField(max_length=200, null=True)
    town = models.CharField(max_length=200, null=True)

    def _str_(self):
        return self.province