from rest_framework import serializers
from rest_framework.utils import serializer_helpers
from .models import *

class Datesserializer(serializers.ModelSerializer):

    class Meta:
        model = Dates
        fields = ('__all__' )
        #fields = ('matched','volume', 'open','close' )
    

class Matchserializer(serializers.ModelSerializer):

    class Meta:
        model = Match
        fields = ('name','phonenumber','age')


class Userserializer(serializers.ModelSerializer):

    class Meta:
        model = User
        fields = ('__all__')

class Smsserializer(serializers.ModelSerializer):

    class Meta:
        model = Sms
        fields = ('messages','messagesid')

class Locationserializer(serializers.ModelSerializer):

    class Meta:
        model = Location
        fields = ('town','province')
