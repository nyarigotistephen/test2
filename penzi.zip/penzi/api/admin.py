from typing import Match
from django.contrib import admin
from .models import *

admin.site.register(Dates)
admin.site.register(Sms)
admin.site.register(User)
admin.site.register(Match)
admin.site.register(Location)
# Register your models here.
