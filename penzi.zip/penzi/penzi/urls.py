from os import name
from django.contrib import admin
from django.conf.urls import include, url
from django.urls import path ,include
from rest_framework.urlpatterns import format_suffix_patterns
from api import views 
urlpatterns = [
    path('admin/', admin.site.urls),
    #path('dates/', views.dateslist.as_view(), name="dates"),
    path('users/', views.userlist.as_view(), name="dates"),
    path('smss/', views.smslist.as_view(), name="home"),
    path('matchs/', views.matchlist.as_view(), name=""),
    path('locations/', views.locationlist.as_view()),
    path('',include('app.urls'))
]



urlpatterns= format_suffix_patterns(urlpatterns)